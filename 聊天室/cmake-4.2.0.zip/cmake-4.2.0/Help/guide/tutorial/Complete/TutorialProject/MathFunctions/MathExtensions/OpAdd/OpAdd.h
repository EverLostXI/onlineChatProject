#pragma once

namespace mathfunctions {
double OpAdd(double a, double b);
}
