CMAKE_FASTBUILD_VERBOSE_GENERATOR
---------------------------------

.. versionadded:: 4.2

.. include:: include/ENV_VAR.rst

The ``CMAKE_FASTBUILD_VERBOSE_GENERATOR`` environment variable specifies a custom default
value for the :variable:`CMAKE_FASTBUILD_VERBOSE_GENERATOR` variable in place of the
default values specified by CMake itself.
