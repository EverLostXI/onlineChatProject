namespace mathfunctions {
double OpSub(double a, double b)
{
  return a - b;
}
}
