#pragma once

namespace mathfunctions {
double OpSub(double a, double b);
}
